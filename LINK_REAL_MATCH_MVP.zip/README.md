LINK REAL MATCH MVP
This version uses Socket.IO for real-time two-player matchmaking.
Run it on a Node.js host, then open the same public URL on two devices.
The server pairs waiting players and compares their real answers.
For production: add authentication, database, moderation, rate limits, reconnect handling, HTTPS, scaling and analytics.
