const express=require("express"),http=require("http"),{Server}=require("socket.io");
const app=express(),server=http.createServer(app),io=new Server(server);app.use(express.static("public"));
const queue=[], players=new Map(), rooms=new Map();
const questions=[
["Pick a vibe","🌙 Night","☀️ Day"],["Weekend plan?","🏠 Stay in","🌍 Go out"],
["Choose one","🍕 Pizza","🍔 Burger"],["Energy","🌊 Calm","🔥 Wild"],["Dream trip","🏔️ Mountains","🏝️ Beach"]
];
function match(s){while(queue.length){const p=queue.shift();if(p.connected&&p.id!==s.id){
 const room="r_"+p.id+"_"+s.id;s.join(room);p.join(room);players.set(s.id,{room,peer:p.id});players.set(p.id,{room,peer:s.id});
 rooms.set(room,{answers:{},done:0});io.to(room).emit("matched",{questions});return}}
 if(!queue.includes(s))queue.push(s);s.emit("waiting");
}
io.on("connection",s=>{
 s.on("find",()=>match(s));
 s.on("answer",({round,choice})=>{
  const m=players.get(s.id);if(!m)return;const r=rooms.get(m.room);if(!r)return;
  if(!r.answers[round])r.answers[round]={};r.answers[round][s.id]=choice;
  s.to(m.room).emit("peer_answer",{round});
  const a=r.answers[round];if(a[m.peer]!==undefined&&a[s.id]!==undefined){
   io.to(m.room).emit("round_result",{round,same:a[m.peer]===a[s.id]});
  }
  if(Object.keys(r.answers).length===5){let same=0;for(let i=0;i<5;i++)if(r.answers[i]&&r.answers[i][s.id]!==undefined&&r.answers[i][m.peer]!==undefined&&r.answers[i][s.id]===r.answers[i][m.peer])same++;io.to(m.room).emit("finished",{score:same*20});}
 });
 s.on("disconnect",()=>{const i=queue.indexOf(s);if(i>=0)queue.splice(i,1);const m=players.get(s.id);if(m){s.to(m.room).emit("peer_left");players.delete(s.id);players.delete(m.peer);rooms.delete(m.room)}});
});
server.listen(process.env.PORT||3000);
